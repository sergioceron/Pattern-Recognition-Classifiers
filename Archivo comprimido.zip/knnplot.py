import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets

iris = datasets.load_iris()
Y = iris.target
ds = np.column_stack((iris.data, Y))

markers = [ 'o', 'v', 'x' ]
for i in range( 3 ):
    clase = np.array( [e[0:4] for e in ds if e[4] == i] )
    print clase
    plt.scatter(clase[:,0], clase[:,3], marker=markers[i], color='0.5', s=50, facecolors='none', edgecolors='gray')

plt.grid()
plt.show()
